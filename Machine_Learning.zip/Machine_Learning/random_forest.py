#importation des librairies
import pandas as pd
from imblearn.over_sampling import SMOTE
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.metrics import classification_report, f1_score
from sklearn.utils.validation import check_X_y
from sklearn.metrics import confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns



df = pd.read_csv("DF_Discret.csv")

# Définition des features et de la cible
X = df.drop(columns=["gravite_accident"])
y = df["gravite_accident"]

# Équilibrage des classes avec SMOTE
sampling_strategy = {
    0: max(y.value_counts()[0], int(y.value_counts()[0] * 1)),  
    1: max(y.value_counts()[1], int(y.value_counts()[1] * 1.25)),  
    2: max(y.value_counts()[2], int(y.value_counts()[2] * 20))  
}

smote = SMOTE(sampling_strategy=sampling_strategy, random_state=42)
X_resampled, y_resampled = smote.fit_resample(X, y)

# Vérification des données après SMOTE
X_resampled, y_resampled = check_X_y(X_resampled, y_resampled)

# Séparation en données d'entraînement et de test
X_train, X_test, y_train, y_test = train_test_split(X_resampled, y_resampled, random_state=42, test_size=0.2, stratify=y_resampled)

# Définition du modèle Random Forest
rf = RandomForestClassifier(random_state=42)

# Grille de recherche des hyperparamètres
param_grid = {
    'n_estimators': [100, 200],
    'criterion': ['gini', 'entropy'],
    'min_samples_split': [2, 5, 10],
    'max_depth': [10, 14, 18]
}

# Grid Search
grid_search = GridSearchCV(rf, param_grid, cv=3, scoring='f1_macro', n_jobs=-1)
grid_search.fit(X_train, y_train)

# Meilleurs hyperparamètres
print("Meilleurs paramètres :", grid_search.best_params_)

# Entraînement du meilleur modèle
best_rf = grid_search.best_estimator_
best_rf.fit(X_train, y_train)

# Prédictions
y_pred_rf = best_rf.predict(X_test)

# Évaluation
print("F1-score macro :", f1_score(y_test, y_pred_rf, average='macro'))
print("Rapport de classification :\n", classification_report(y_test, y_pred_rf))


print("Meilleurs paramètres:", grid_search.best_params_)
print("Meilleur score:", grid_search.best_score_)

# Évaluation sur le jeu de test
y_pred = grid_search.best_estimator_.predict(X_test)
print(classification_report(y_test, y_pred))

# Matrice de confusion
cm = confusion_matrix(y_test, y_pred)
labels = sorted(y.unique())  # Récupère les classes présentes dans y
plt.figure(figsize=(6, 5))
sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", xticklabels=labels, yticklabels=labels)
plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.title("Confusion Matrix")
plt.show()

# Distribution des classes prédites
plt.figure(figsize=(6, 4))
sns.histplot(y_pred, bins=3, kde=True, discrete=True)
plt.xlabel("Predicted Class")
plt.ylabel("Count")
plt.title("Distribution of Predicted Classes")
plt.xticks(labels)
plt.show()
rf_best = grid_search.best_estimator_  
feature_importance = rf_best.feature_importances_

# Affichage des importances des features
plt.figure(figsize=(10, 5))
sns.barplot(x=X.columns, y=feature_importance)
plt.xticks(rotation=90)
plt.title("Feature Importance in Random Forest")
plt.show()
